echo ""
sleep 2

# Touch optimization
settings put system pointer_speed 7
settings put system touch_slop 4
settings put secure long_press_timeout 250
settings put system double_tap_timeout 100
settings put system multi_press_timeout 40
settings put system pointer_gesture_duration 40
setprop debug.touch.size.scale 1
setprop debug.touch.size.calibration geometric
setprop debug.touch.orientation.calibration interpolated
setprop debug.touch.distance.calibration area
setprop debug.touch.pressure.calibration amplitude
setprop debug.touch.gestureMode spots

# Swipe tuning for fast flicks
cmd device_config put touchscreen input_drag_min_switch_speed 800
setprop debug.MovementSpeedRatio 0.9
setprop debug.TapInterval 0.05ms
setprop debug.TapSlop 1px

# Latency and frame rate optimization
settings put system purgeable_assets 1
setprop debug.windowsmgr.max_events_per_sec 90
settings put global min_pointer_dur 8
setprop debug.view.scroll_friction 0

# Touchpanel gaming mode flags (if supported by device)
settings put system touchpanel_game_switch_enable 1
settings put system touchpanel_oplus_tp_limit_enable 0
settings put system touchpanel_oplus_tp_direction 1

# Basic CPU tuning to reduce jank in touch events
settings put system stune_foreground_schedtune.boost 20
settings put system stune_foreground_schedtune.sched_boost_enabled 1

# Swipe test (optional randomized swipe to wake touch path)
x1=$(expr $RANDOM % 1000 + 1)
y1=$(expr $RANDOM % 1000 + 1)
x2=$(expr $RANDOM % 1000 + 1)
y2=$(expr $RANDOM % 1000 + 1)
duration=$(expr $RANDOM % 500 + 300)
input swipe $x1 $y1 $x2 $y2 $duration >/dev/null 2>&1

echo "Touch optimization applied."