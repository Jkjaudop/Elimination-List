echo "Reverting system touch and performance tweaks..."

# Reset system settings
settings delete system pointer_speed
settings delete system touch_slop
settings delete secure long_press_timeout
settings delete system double_tap_timeout
settings delete system multi_press_timeout
settings delete system pointer_gesture_duration
settings delete global min_pointer_dur
settings delete system purgeable_assets

# Reset touchpanel/game mode flags (device-specific)
settings delete system touchpanel_game_switch_enable
settings delete system touchpanel_oplus_tp_limit_enable
settings delete system touchpanel_oplus_tp_direction

# Reset CPU scheduler tweaks
settings delete system stune_foreground_schedtune.boost
settings delete system stune_foreground_schedtune.sched_boost_enabled

# Reset touchscreen config (device_config)
cmd device_config delete touchscreen input_drag_min_switch_speed

# Reset system properties (props)
resetprop debug.touch.size.scale
resetprop debug.touch.size.calibration
resetprop debug.touch.orientation.calibration
resetprop debug.touch.distance.calibration
resetprop debug.touch.pressure.calibration
resetprop debug.touch.gestureMode
resetprop debug.MovementSpeedRatio
resetprop debug.TapInterval
resetprop debug.TapSlop
resetprop debug.windowsmgr.max_events_per_sec
resetprop debug.view.scroll_friction

echo "System touch settings reverted to default."